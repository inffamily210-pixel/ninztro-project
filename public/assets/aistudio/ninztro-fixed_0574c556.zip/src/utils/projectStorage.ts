import { ProjectState, MediaClip, AudioTrack, TrackingPoint3D, Tracked3DElement } from '../types/editor.ts';

export interface ProjectMetadata {
  id: string;
  title: string;
  thumbnailUrl: string; // empty string = no thumbnail yet (blank project)
  duration: number;
  clipsCount: number;
  aspectRatio: '16:9' | '9:16' | '1:1' | '21:9';
  updatedAt: string;
  createdAt: string;
  effectsCount: number;
  shareCode?: string;
}

export interface StoredProjectData {
  metadata: ProjectMetadata;
  state: ProjectState;
}

const STORAGE_KEY = 'ninztro_saved_projects_v1';

export interface ProjectCreateOptions {
  canvasWidth?: number;
  canvasHeight?: number;
  aspectRatioLabel?: '16:9' | '9:16' | '1:1' | '4:5' | '21:9';
  fps?: number;
}

/**
 * Creates a brand new BLANK project (no clips, no audio, no effects) with configurable
 * resolution & fps (30 to 144 FPS). Users add their own media afterwards, like CapCut.
 */
export function createNewProjectState(title = 'Project Baru', options?: ProjectCreateOptions): ProjectState {
  const fps = Math.min(144, Math.max(30, options?.fps ?? 30));
  const canvasWidth = options?.canvasWidth ?? 1920;
  const canvasHeight = options?.canvasHeight ?? 1080;
  const aspectRatioLabel = options?.aspectRatioLabel ?? (canvasWidth === 1080 && canvasHeight === 1920 ? '9:16' : '16:9');

  return {
    title,
    canvasWidth,
    canvasHeight,
    aspectRatioLabel,
    fps,
    currentTime: 0,
    duration: 5.0, // placeholder length of an empty timeline; recalculated when clips are added
    isPlaying: false,
    selectedClipId: null,
    selected3DElementId: null,
    selectedAudioTrackId: null,
    clips: [],
    audioTracks: [],
    trackingPoints: [],
    trackedElements: [],
    isTrackingModeActive: false,
    activeTab: 'media',
    beatSyncEnabled: false,
    cameraFrustumVisible: false,
  };
}

/**
 * Generates an export shareable link and compact project payload code
 */
export function generateShareableLink(project: ProjectState): { shareLink: string; shareCode: string } {
  // Create clean lightweight representation for sharing
  const sharePayload = {
    v: 1,
    title: project.title,
    aspect: project.aspectRatioLabel,
    duration: project.duration,
    clipsCount: project.clips.length,
    trackedCount: project.trackedElements.length,
    timestamp: Date.now(),
  };

  const shareCode = btoa(unescape(encodeURIComponent(JSON.stringify(sharePayload))))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '')
    .slice(0, 16);

  // Generates canonical share URL for the project
  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://ninztro.studio';
  const shareLink = `${baseUrl}/?share=${shareCode}&title=${encodeURIComponent(project.title)}`;

  return { shareLink, shareCode };
}

/**
 * Loads all user saved projects from LocalStorage.
 * An empty list stays empty: deleted projects must never come back by themselves.
 */
export function loadProjectsFromStorage(): StoredProjectData[] {
  if (typeof window === 'undefined') return [];

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to load projects from storage:', err);
  }

  return [];
}

/**
 * Persists list of projects to LocalStorage
 */
export function saveProjectsToStorage(projects: StoredProjectData[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
  } catch (err) {
    console.warn('Failed to save projects to storage:', err);
  }
}

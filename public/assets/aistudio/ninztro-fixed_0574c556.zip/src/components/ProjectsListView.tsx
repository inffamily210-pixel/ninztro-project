import React, { useState, useMemo } from 'react';
import {
  FolderOpen,
  Plus,
  Play,
  Share2,
  Trash2,
  Copy,
  Clock,
  Ratio,
  Film,
  Layers,
  Search,
  Check,
  ExternalLink,
  MoreVertical,
  FolderPlus,
  X,
} from 'lucide-react';
import { StoredProjectData, generateShareableLink } from '../utils/projectStorage.ts';
import { ProjectState } from '../types/editor.ts';
import { playSynthSound } from '../utils/audioSynth.ts';

interface ProjectsListViewProps {
  projects: StoredProjectData[];
  onOpenProject: (projectData: StoredProjectData) => void;
  onCreateNewProject: () => void;
  onDuplicateProject: (projectId: string) => void;
  onDeleteProject: (projectId: string) => void;
  onNavigateToAbout: () => void;
}

export const ProjectsListView: React.FC<ProjectsListViewProps> = ({
  projects,
  onOpenProject,
  onCreateNewProject,
  onDuplicateProject,
  onDeleteProject,
  onNavigateToAbout,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRatio, setFilterRatio] = useState<'all' | '16:9' | '9:16' | '1:1'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<StoredProjectData | null>(null);

  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      const matchesSearch =
        p.metadata.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.metadata.id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRatio = filterRatio === 'all' || p.metadata.aspectRatio === filterRatio;
      return matchesSearch && matchesRatio;
    });
  }, [projects, searchQuery, filterRatio]);

  const handleCopyShareLink = (project: StoredProjectData, e: React.MouseEvent) => {
    e.stopPropagation();
    playSynthSound('laser');
    const { shareLink } = generateShareableLink(project.state);

    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareLink).catch(() => {});
    }
    setCopiedId(project.metadata.id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  return (
    <div className="flex-1 bg-[#0c0e14] text-zinc-200 overflow-y-auto custom-scrollbar select-none">
      <div className="max-w-6xl mx-auto px-3 sm:px-6 py-4 sm:py-8 space-y-4 sm:space-y-6">
        {/* View Header */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4 border-b border-zinc-800 pb-4 sm:pb-5">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-2xl font-extrabold tracking-tight text-white font-sans">
                Daftar Semua Project
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-zinc-300 font-mono text-xs font-semibold border border-zinc-700">
                {projects.length} Project
              </span>
            </div>
            <p className="hidden sm:block text-xs text-zinc-400 mt-1">
              Kelola, lanjutkan editing, atau bagikan tautan project kepada rekan kerja dan klien.
            </p>
          </div>

          {/* Action button */}
          <button
            type="button"
            onClick={onCreateNewProject}
            className="flex items-center justify-center gap-2 px-4 py-3 sm:py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 sm:bg-none sm:bg-zinc-100 sm:hover:bg-white text-white sm:text-zinc-950 font-bold text-sm sm:text-xs shadow-lg active:scale-[0.98] transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Buat Project Baru</span>
          </button>
        </div>

        {/* Search & Filter Toolbar */}
        {projects.length > 0 && (
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama project..."
              className="w-full bg-[#11141d] border border-zinc-800 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-600"
            />
          </div>

          {/* Ratio filter tabs */}
          <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto no-scrollbar max-w-full">
            <span className="text-[11px] text-zinc-500 mr-1 hidden sm:inline">Format:</span>
            {[
              { id: 'all', label: 'Semua' },
              { id: '16:9', label: '16:9' },
              { id: '9:16', label: '9:16' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilterRatio(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors shrink-0 ${
                  filterRatio === tab.id
                    ? 'bg-zinc-800 text-white font-semibold border border-zinc-700'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-850'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
        )}

        {/* Toast confirmation if link copied */}
        {copiedId && (
          <div className="p-3 rounded-xl bg-zinc-850 border border-zinc-700 text-zinc-200 flex items-center justify-between text-xs animate-fadeIn">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span>Tautan Berbagi Project berhasil disalin ke clipboard! Siap dikirimkan.</span>
            </div>
            <span className="text-[10px] font-mono text-zinc-400">https://ninztro.studio/?share=...</span>
          </div>
        )}

        {/* Projects Grid */}
        {filteredProjects.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-5">
            {filteredProjects.map((project) => (
              <div
                key={project.metadata.id}
                onClick={() => onOpenProject(project)}
                className="group rounded-2xl bg-[#11141d] border border-zinc-800 hover:border-zinc-700 overflow-hidden shadow-lg transition-all cursor-pointer flex flex-col"
              >
                {/* Thumbnail Header */}
                <div className="relative aspect-video w-full bg-black overflow-hidden">
                  {project.metadata.thumbnailUrl ? (
                    <img
                      src={project.metadata.thumbnailUrl}
                      alt={project.metadata.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-90 group-hover:opacity-100"
                    />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-zinc-900 to-zinc-800 flex items-center justify-center">
                      <Film className="w-8 h-8 text-zinc-600" />
                    </div>
                  )}
                  {/* Aspect Ratio, Duration & FPS badge */}
                  <div className="absolute top-2 left-2 flex flex-wrap items-center gap-1">
                    <span className="px-2 py-0.5 rounded bg-black/80 backdrop-blur-md text-[10px] font-mono text-zinc-300 font-semibold border border-zinc-800">
                      {project.metadata.aspectRatio}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-black/80 backdrop-blur-md text-[10px] font-mono text-zinc-300 border border-zinc-800">
                      {project.metadata.duration.toFixed(1)}s
                    </span>
                    {project.state?.fps && (
                      <span className="px-2 py-0.5 rounded bg-cyan-950/80 backdrop-blur-md text-[10px] font-mono text-cyan-300 border border-cyan-800/60 font-semibold">
                        {project.state.fps} FPS
                      </span>
                    )}
                  </div>

                  {/* Play overlay button on hover */}
                  <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-white/90 text-black flex items-center justify-center shadow-xl">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </div>
                  </div>
                </div>

                {/* Card Content Body */}
                <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between space-y-2 sm:space-y-3">
                  <div>
                    <h3 className="font-bold text-white text-sm group-hover:text-zinc-100 truncate">
                      {project.metadata.title}
                    </h3>
                    <div className="flex items-center gap-3 text-[11px] text-zinc-400 font-mono mt-1">
                      <span className="flex items-center gap-1">
                        <Film className="w-3.5 h-3.5 text-zinc-500" />
                        <span>{project.metadata.clipsCount} Klip</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Layers className="w-3.5 h-3.5 text-zinc-500" />
                        <span>{project.metadata.effectsCount} Efek 3D</span>
                      </span>
                    </div>
                  </div>

                  {/* Footer toolbar */}
                  <div className="pt-2 sm:pt-3 border-t border-zinc-800 flex items-center justify-end sm:justify-between text-xs">
                    <span className="hidden sm:inline text-[10px] text-zinc-500">
                      Disunting {project.metadata.updatedAt}
                    </span>

                    <div className="flex items-center gap-1">
                      {/* Copy Share Link button */}
                      <button
                        type="button"
                        onClick={(e) => handleCopyShareLink(project, e)}
                        title="Salin Tautan Berbagi Project"
                        className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                      </button>

                      {/* Duplicate Project */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDuplicateProject(project.metadata.id);
                        }}
                        title="Duplikat Project"
                        className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      {/* Delete Project */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setPendingDelete(project);
                        }}
                        title="Hapus Project"
                        className="p-2 sm:p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 transition-colors"
                      >
                        <Trash2 className="w-4 h-4 sm:w-3.5 sm:h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="py-16 px-6 text-center border border-dashed border-zinc-800 rounded-2xl bg-[#11141d]/50 flex flex-col items-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">
              <FolderPlus className="w-6 h-6 text-zinc-500" />
            </div>
            <p className="text-sm font-semibold text-white">Belum ada project</p>
            <p className="text-xs text-zinc-400 max-w-xs">Ketuk tombol "Buat Project Baru" untuk mulai. Project baru kosong dan siap kamu isi dengan video atau foto sendiri.</p>
          </div>
        ) : (
          <div className="p-12 text-center border border-dashed border-zinc-800 rounded-2xl bg-[#11141d]/50 space-y-3">
            <p className="text-zinc-400 text-sm">Tidak ada project yang cocok dengan filter pencarian.</p>
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setFilterRatio('all');
              }}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-white transition-colors"
            >
              Reset Filter
            </button>
          </div>
        )}
      </div>

      {/* Delete confirmation (bottom sheet on phones, centered dialog on desktop) */}
      {pendingDelete && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm animate-fadeIn"
          onClick={() => setPendingDelete(null)}
        >
          <div
            className="w-full sm:max-w-sm bg-[#11141d] border border-zinc-800 rounded-t-2xl sm:rounded-2xl p-5 pb-[calc(1.25rem+env(safe-area-inset-bottom))] space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1 min-w-0">
                <h3 className="text-sm font-bold text-white">Hapus project ini?</h3>
                <p className="text-xs text-zinc-400 break-words">
                  "{pendingDelete.metadata.title}" akan dihapus permanen dan tidak bisa dikembalikan.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPendingDelete(null)}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-white"
                aria-label="Tutup"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPendingDelete(null)}
                className="flex-1 py-3 sm:py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm sm:text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteProject(pendingDelete.metadata.id);
                  setPendingDelete(null);
                }}
                className="flex-1 py-3 sm:py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm sm:text-xs font-bold"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
